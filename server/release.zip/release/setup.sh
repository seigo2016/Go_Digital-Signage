git clone https://github.com/ImageMagick/ImageMagick.git

cd ImageMagick/ && ./configure && sudo -S make && sudo -S make install

sudo -S ldconfig /user/local/lib

wget 